#include <stdio.h>
#include <string.h>
#include "browser.h"
// ─────────────────────────────────────────────
//  PROTOTYPES
// ─────────────────────────────────────────────
void clear_screen(void);
void deex_draw_taskbar(void);
void deex_desktop(void);
int  is_valid_deex_code(const char *code);
void cmd_loaddeex(void);

// ─────────────────────────────────────────────
//  CLEAR SCREEN (DEEX WORLD ENTRY)
// ─────────────────────────────────────────────
void clear_screen(void) {
    // ANSI escape: clear screen + move cursor to top-left
    printf("\033[2J\033[H");
}

// ─────────────────────────────────────────────
//  TASKBAR (BOTTOM, WITH ❖ START)
// ─────────────────────────────────────────────
void deex_draw_taskbar(void) {
    printf("┌──────────────────────────────────────────────────────────────┐\n");
    printf("│ ❖ Start                                             [DEEX]   │\n");
    printf("└──────────────────────────────────────────────────────────────┘\n");
}

// ─────────────────────────────────────────────
//  DEEX DESKTOP MODE (SEPARATE FROM CTL-CORE)
// ─────────────────────────────────────────────
void deex_desktop(void) {
    char input[64];

    while (1) {
        clear_screen();

        // Desktop header / wallpaper area
        printf("==============================================================\n");
        printf("                    ZAP SIMPLE First DEEX DESKTOP             \n");
        printf("==============================================================\n");
    }

}


void deexbout () {
printf ("COME TO LIFE\n");
printf ("COME TO LIFE Core 1,2 capable of basic desktop experience 🔥\n");
printf ("First DEEX Update 00,01\n");


}


void deexupd () {

    printf ("First DEEX Update 00,02 \n");
    printf ("First DEEX now is going to have standard windows and things (like windows 1.0)\n");




}

void menu () {
printf ("Would you like to open an app?(type NO if not):\n");
scanf ("Would you like to open an app?(type NO if not):");

}

void browservers () {
    printf ("First DEEX's Browser [CURRENTLY NO NAME]\n");
    printf ("First DEEX's Browser Version : 0\n");
    printf ("First DEEX's Browser Possible Name : GalaxyBrowser\n");
    printf ("Type 'browser' to open the browser\n");
    printf ("About :");
    printf ("COME TO LIFE's BRAND NEW browser now available!");
}



/* Secret page/password check */
void secret_page(void) {
    char pass[64];
    printf("Enter password: ");
    if (!fgets(pass, sizeof(pass), stdin)) {
        return;
    }
    pass[strcspn(pass, "\n")] = 0;
    if (strcmp(pass, "opensesame") == 0) {
        printf("Access granted — welcome to the secret page!\n");
        printf("🌟 Secret content: The prototype works. 🌟\n");
    } else {
        printf("Incorrect password.\n");
    }
}

int main() {
    char input[256];

    printf("XCWORK's COME TO LIFE Core Loaded First DEEX\n");
    printf("Type ''browser'' to open First DEEX's Browser.\n\n");
    printf("And type ''browserv'' to show about the browser.\n");

    while (1) {
    printf("DEEX | ");

    if (!fgets(input, sizeof(input), stdin)) {
        break;
    }

    input[strcspn(input, "\n")] = 0;

    if (strcmp(input, "draw_taskbar") == 0) {
        deex_draw_taskbar();
    }
    else if (strcmp(input, "desktop") == 0) {
        deex_desktop();
    }
    else if (strcmp(input, "aboutdeex") == 0) {
        deexbout();
    }
    else if (strcmp(input, "deexupd") == 0) {
        deexupd();
    }
    else if (strcmp(input, "menu") == 0) {
        menu();
    }
    else if (strcmp(input, "shutdown") == 0) {
        printf("Shutting down CTL's First DEEX\n");
        break;
    }
    else if (strcmp(input, "browser") == 0) {
        deex_browser();
    }
    else if (strcmp(input, "browserv") == 0) {
        browservers();
    }
   else if (strcmp(input, "secret") == 0) {
        secret_page();
    }
    else if (strlen(input) == 0) {
        continue;
    }
    else {
        printf("Unknown First DEEX Command: %s\n", input);
    }
}

return 0;
}