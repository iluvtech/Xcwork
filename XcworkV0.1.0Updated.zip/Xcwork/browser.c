// browser.c
#include <stdio.h>
#include <string.h>
void zapstudios () {
printf("Zap Simple Browse Page.\n");
printf("This page is only available on XCWORK.\n");
printf("XCWORK Pre-Release V 0.0.8 is now in works. I've been working so much on it that i decided to skip .6 and .7 since they pretty much existed.\n");
printf("XCWORK's COME TO LIFE's DEEX's Browser can't open webpages so i wrote this small thingy to make it seem like it can\n");
printf("XCWORK Release date : May, 10th , 2026\n");
printf("it might get delayed tough\n");
printf("use the SCAN command in the browser to get Easter Egg");
}

void scan() {
    printf("Easter Egg :");
    scanf ("eegg");
}



void deex_browser(void) {
    char url[256];
    char input[32]; 
    while (1) {
        printf("\n==============================\n");
        printf("        DEEX BROWSER\n");
        printf("==============================\n");
        printf("Type 'back' to return to DEEX.\n\n");

        printf("open: ");
        if (!fgets(url, sizeof(url), stdin))
            return;
        url[strcspn(url, "\n")] = 0;

        if (strcmp(url, "back") == 0)
            break;

        if (url[0] == '\0')
            continue;

        // Fake page content for now
        printf("\nLoading %s ...\n", url);
        printf("--------------------------------\n");
        printf("DEEX Browser\n");
        printf("You tried to open: %s\n", url);
        printf("Real internet coming in a later saga.\n");
        printf("Error 001\n");
        printf("--------------------------------\n");

        printf("\nPress Enter to continue...");
        fgets(input, sizeof(input), stdin);
    }
}
int main() {
    char input[256];

    printf ("Welcome To First DEEX's Browser. It does not open any WebPages yet.");
    while (1) {
    printf("Browser :  ");

    if (!fgets(input, sizeof(input), stdin)) {
        break;
    }

    input[strcspn(input, "\n")] = 0;

    if (strcmp(input, "zapstudios") == 0) {
        zapstudios();
    }
    if (strcmp(input, "scan") == 0) {
        scan() ;
    }
    else if (strlen(input) == 0) {
        continue;
    }
    else {
        printf("Unknown First Browser Command: %s\n", input);
    }
}

return 0;
}