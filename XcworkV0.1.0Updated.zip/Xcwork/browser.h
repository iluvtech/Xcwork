// browser.h
#ifndef BROWSER_H
#define BROWSER_H

void deex_browser(void);

#endif