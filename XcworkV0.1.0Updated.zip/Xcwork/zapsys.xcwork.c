#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "deex.h"
/*Zap Simple V0.1.0 (XCWORK)*/


//feel free to use my code. You can mod it. You can make it an Actual OS. Do whatever.






//
// ─────────────────────────────────────────────
//   ZAP SIMPLE –  XC‑WORK
//   V 1.0.0
// ─────────────────────────────────────────────
//

void development () {
    printf ("Hello everybody i'm the man behind Zap Simple and I just wanted to say:");
    printf ("If you see this, thank you for using XCWORK. It is one of my first projects that i actually focused on.\n");
    printf ("I've codedd all of this by myself, and i gotta say it wasn't as hard as i tought it would be.\n");
    printf ("And for any devs who wanna change the world by doing a tiny open-source project, it's worth it.\n");
    printf ("Also I've only created the pure code of Zap Simple, if you wanna take my code, and actually make it an OS, or mod it, its absolutely ok.\n");
    printf ("If this ever becomes popular i'm gonna keep updating XCWORK until it becomes a full blown OS. \n");
    printf ("Thank you.\n");
}

// ─────────────────────────────────────────────
//  DEEX (DEsktop EXpirience)
// ─────────────────────────────────────────────
void cmd_loaddeex() {
    char code[256];
    printf("Enter DEEX code (3 letters with 1 capital + 3 numbers): ");
    
    if (!fgets(code, sizeof(code), stdin)) {
        return;
    }
    
    code[strcspn(code, "\n")] = 0;
    
    if (is_valid_deex_code(code)) {
        printf("Valid code. Loading DEEX...\n");
        // Load ctldeex.c functionality here
        system("./ctldeex");
    } else {
        printf("Invalid DEEX code.\n");
    }
}

int is_valid_deex_code(const char *code) {
    if (strlen(code) != 6)
        return 0;

    int has_upper = 0;
    int letter_count = 0;
    int number_count = 0;

    for (int i = 0; i < 6; i++) {
        if (code[i] >= 'a' && code[i] <= 'z') {
            letter_count++;
        } else if (code[i] >= 'A' && code[i] <= 'Z') {
            letter_count++;
            has_upper = 1;
        } else if (code[i] >= '0' && code[i] <= '9') {
            number_count++;
        } else {
            return 0;
        }
    }

    return (letter_count == 3 && number_count == 3 && has_upper == 1);
}

//_________________________________________________
//
//            ERROR CODES
//_________________________________________________
void cmd_errors () {
printf("Error Codes List\n");
printf("001 => Feature not implemented yet.\n\n");
printf("002 => Code Error. Rebooting might fix this.\n");
printf("003 => Driver Error\n");

printf("Component Error Section\n\n");
printf("G35 => PSU(Power Supply) might not be recommended. Please check its tier on ZTT's PSU Tierlist (https://docs.google.com/spreadsheets/d/1akCHL7Vhzk_EhrpIGkz8zTEvYfLDcaSpZRB6Xt6JWkc/edit?gid=1719706335#gid=1719706335)\n");
printf("GC6 => CPU(Proccesor) might be outdated or way too old. You might be able to still use Zap Simple just fine but this is your „be careful it might die soon!” warning!\n");
printf("GG7 => GPU (Graphics Card) might be outdated or way too old. You might be able to still use Zap Simple just fine but this is your „be careful it might die soon!” warning!\n");

printf("MOTHERBOARD ERRORS SUBSECTION \n\n");
printf("GM01 => Fatal Motherboard Error\n\n");
printf("GM02 => Fried Motherboard\n");
printf("GM03 => Fried CMOS\n");
printf("GM04 => Connected Device Error.\n");



}


// ─────────────────────────────────────────────
//  NEWS COMMAND
// ─────────────────────────────────────────────
void cmd_news() {
    printf("\nZap Simple – Update News\n");
    printf("-------------------------\n");
    printf("XCWORK's COME TO LIFE Core Implemented.Zap Simple Gets closer to release with its 0.0.7 update. slowly evolving it.\n");
    printf("COME TO LIFE CORE V 1,1 update is out!XCWORK is now cappable of more advanced things!XCWORK Update 0.0.8 might bring Desktop Expirience to XCWORK! \n");
}

//Dialog Command (too lazy to do the ______ ritual)

void cmd_dialog() {
    printf("Welcome to Dialog. This is basically a time capsule. and no you dont get to choose what to say\n");
    printf("This is a secret command. So congrats on finding it. And no im not putting it in the help command.\n");
    printf("And I Am too lazy so im keeping it empty. for now.\n");
    printf("-The one and only dev, On Friday, 30 Jan 2026 at 10:52 AM\n");

}

// ─────────────────────────────────────────────
//  HELP COMMAND
// ─────────────────────────────────────────────
void cmd_help() {
    printf("\nZap Simple – XCWORK's Core Commands:\n");
    printf("  help       - show this\n");
    printf("  news       - show update information\n");
    printf("  load_deex       - enter DEEX\n");
    printf("  settings   - enter Special Settings\n");
    printf("  exit       - leave Zap Simple shell\n\n");
    printf("  deex - load DEsktop EXpirience\n");
}
void loadprintfs() {
    printf("HELLO WORLD!\n");
    printf("COME TO LIFE now ain't gon contain any of that AI things. It's the only OS thats doin this(except linux but who uses linux really)\n");
    printf("Now Zap Simple V 0.0.8 has suffered some MASSIVE changes. DEEX, the browser (that works like shit). what should i add next?\n");
}

// ─────────────────────────────────────────────
//  ZapSys Info (i gotta stop doin ts fuckass _____ ritual)
// ─────────────────────────────────────────────
void cmd_sysinfo() {
    printf("\n========== SYS INFO ==========\n");

    printf ("Zap Simple V 0.1.0\n\n");
    printf ("Core : XCWORK's COME TO LIFE (CTL) Update 1,2");
    

    printf("\n======================================\n\n");

}

void cmd_aboutctl () {


printf ("COME TO LIFE CORE");
printf ("The brand new core of Zap Simple, made just for you.\n");
printf ("COME TO LIFE and xcwork evolve fast everyday, and get closer to their full potential.\n");
printf ("Sadly , CTL can't live forever. its gonna stay arround until probably XCWORK V2.0.0 , 2.5.0 , or even 3.0.0 (idk i haven't tought of it until now).\n");
printf ("The replacement for CTL is going to be TMTTM(Take Me to the Moon). I'm not gonna start developing it for XCWORK until a lot more time. Prob V 1.7.0.\n");
printf ("if u are unsure of what xcwork is lemme explain it to you.\n");
printf ("XCWORK(or XC-WORK or X-CWORK) is Zap Simple's primary development version. it's using COME TO LIFE core, and is the BEST for everyday usage. its free. fast . reliable. It's also open source.\n");
//COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE COME TO LIFE
}


void cmd_sset() {

    printf ("im not coding this");
}




// ─────────────────────────────────────────────
//  MAIN SHELL LOOP
// ─────────────────────────────────────────────
int main() {
    char input[256];

    printf("Zap Simple - XCWORK's COME TO LIFE Core Loaded.\n");
    printf("Type 'help' for commands.\n\n");

    while (1) {
        printf("zap > ");

        if (!fgets(input, sizeof(input), stdin)) {
            break;
        }

        // remove newline
        input[strcspn(input, "\n")] = 0;

        // parse commands
        if (strcmp(input, "help") == 0) {
            cmd_help();
        }
        else if (strcmp(input, "news") == 0) {
            cmd_news();
        }
        else if (strcmp(input, "deex") == 0) {
            cmd_loaddeex();
        }
        else if (strcmp(input, "settings") == 0) {
            cmd_sset();
        }
        else if (strcmp(input, "dialog") ==0) {
            cmd_dialog();
        }
        else if (strcmp(input, "loadprintfs") ==0) {
            loadprintfs();
        }
        else if (strcmp(input, "exit") == 0) {
            printf("Exiting Zap Simple.\n");
            break;
        }
        else if (strlen(input) == 0) {
            continue;
        }
        else {
            printf("Unknown command: %s\n", input);
        }
    }

    return 0;
}